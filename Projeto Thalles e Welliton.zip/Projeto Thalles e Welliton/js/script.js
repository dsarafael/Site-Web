var site = site || {};
var offset = $(document).scrollTop();

(function($){
    // USE STRICT
    "use strict";

    site = {

    	init:function(){
        site.menuSmall();
        site.slideHome();
        site.galeria();
	    },
      menuSmall:function(){
        $('.btn-close').click(function(event) {
          $('#menu').removeClass('in');
        });
      },

      slideHome:function(){
        var owl = $('#js-accessories');
        owl.owlCarousel({
          animateIn: 'fadeIn',
          items: 5,
          stagePadding:0,
          smartSpeed:450,
          autoplay:true,
          autoplayTimeout:3000,
          nav: true,
          dots: false,
          responsive:{
            0:{ items:1 },
            480:{ items:2 },
            991:{ items:3 },
            1440:{ items:5 }
          },
        });
      },

      galeria:function(){
        var owl = $('.js-galeria');
        owl.owlCarousel({
          items: 1,
          dots: false,
          thumbs: true,
          thumbsPrerendered: true,
          thumbImage: true,
          thumbContainerClass: 'owl-thumbs',
          thumbItemClass: 'owl-thumb-item'
        });
      },

    };

    var $window = $(window),
        $body = $('body'),
        $header = $('header');

    $(document).ready( site.init() );

    $(window).scroll(function(){
      var offset = $(document).scrollTop();
      site.menuSmall(offset);
    });

    jQuery('.top a').click(function (e) {
	e.preventDefault();
	var top = jQuery(jQuery(this).attr('href')).offset().top;
	jQuery('html,body').animate({
		scrollTop: top - 0
	}, 1500);
});

})(jQuery);
