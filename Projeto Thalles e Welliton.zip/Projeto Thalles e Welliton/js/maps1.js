// *
// * Adicionar multiplos marcadores
// * 2013 - www.marnoto.com
// *

// Váriáveis necessárias
var map;
var infoWindow;

// A variável markersData guarda a informação necessária a cada marcador
// Para utilizar este código basta alterar a informação contida nesta variável

var markersData = [
{ 
   lat: -22.9105030,
   lng: -47.0560100,
   nome: "NOSSO BAR (MERCADO CAMPINEIRO)",
   morada1: "RUA BARAO DE JAGUARA  - 972",
   morada2: "CENTRO",
   codPostal: "CEP: 13015001 - CAMPINAS - SP"
},
{ 
   lat: -22.8290250,
   lng: -47.0979450,
   nome: "CONTAINER FOOD & BAR",
   morada1: "RUA JOAO BAPTISTA DALMEDICO - 861",
   morada2: "PARQUE CEASA",
   codPostal: "CEP: 13082660 - CAMPINAS - SP"
},
{ 
   lat: -22.9034940,
   lng: -47.0635520,
   nome: "BAR DO MERCADAO",
   morada1: "GAL MERCADO MUNICIPAL - S/N",
   morada2: "CENTRO",
   codPostal: "CEP: 13010913 - CAMPINAS - SP"
},
{ 
   lat: -22.9595820,
   lng: -47.0669760,
   nome: "MAFIA DA NAVALHA",
   morada1: "AVENIDA FRANCISCO ALFREDO JUNIOR  - 247",
   morada2: "SWISS PARK",
   codPostal: "CEP: 13049255 - CAMPINAS - SP"
},
{ 
   lat: -23.0099490,
   lng: -47.1409490,
   nome: "MESTRE CERVEJEIRO VIRACOPOS",
   morada1: "RODOVIA SANTOS DUMONT - 66",
   morada2: "PARQUE VIRACOPOS",
   codPostal: "CEP: 13052902 - CAMPINAS - SP"
},
{ 
   lat: -23.0805330,
   lng: -47.2084560,
   nome: "ARMAZEM BEBEER",
   morada1: "RUA REMULO ZOPPI      - 60",
   morada2: "VILA GERGINA",
   codPostal: "CEP: 13333090 - INDAIATUBA - SP"
},
{ 
   lat: -22.9058380,
   lng: -47.0962060,
   nome: "EXPRESSO PIZZA 91",
   morada1: "AV JOSE PANCETTI - 824",
   morada2: "VILA PROOST DE SOUZA",
   codPostal: "CEP: 13033740 - CAMPINAS - SP"
},
{ 
   lat: -23.0749880,
   lng: -47.2044490,
   nome: "BEER HOUSE",
   morada1: "RUA SABIA  - 39",
   morada2: "JARDIM DOM BOSCO",
   codPostal: "CEP: 13333270 - INDAIATUBA - SP"
},
{ 
   lat: -22.8894530,
   lng: -47.0602600,
   nome: "BIERHOF",
   morada1: "RUA TIRADENTES - 940",
   morada2: "VILA ITAPURA",
   codPostal: "CEP: 13023190 - CAMPINAS - SP"
},
{ 
   lat: -26.9131410,
   lng: -49.0854920,
   nome: "BIER VILA",
   morada1: "Rua Alberto Stein - 491",
   morada2: "VILA GERMANICA",
   codPostal: "CEP: 89036200 - BLUMENAU - SC"
},
{ 
   lat: -22.8833200,
   lng: -47.0568160,
   nome: "BONELLI",
   morada1: "RUA BARÃO DE ITAPURA - 2662",
   morada2: "GUANABARA",
   codPostal: "CEP: 13073300 - CAMPINAS - SP"
},
{ 
   lat: -22.8236880,
   lng: -47.0832910,
   nome: "BRONCO BURGER BARAO GERALDO",
   morada1: "RUA AGOSTINHO PATTARO - 199",
   morada2: "BARAO  GERALDO",
   codPostal: "CEP: 13084095 - CAMPINAS - SP"
},
{ 
   lat: -22.8301080,
   lng: -47.0754630,
   nome: "VILA DAS BREJAS",
   morada1: "AVENIDA DOUTOR ROMEU TORTIMA - 593",
   morada2: "JARDIM SANTA GENEBRA",
   codPostal: "CEP: 13084791 - CAMPINAS - SP"
},
{ 
   lat: -23.5314720,
   lng: -46.7864040,
   nome: "FIKA CAFE",
   morada1: "AVENIDA SANTO ANTONIO - 299",
   morada2: "CENTRO",
   codPostal: "CEP: 13800030 - MOGI MIRIM - SP"
},
{ 
   lat: -22.8911870,
   lng: -47.0782520,
   nome: "EMPORIO CIOCCI",
   morada1: "Rua Santo Antonio Claret - 145",
   morada2: "JARDIM CHAPADAO",
   codPostal: "CEP: 13070145 - CAMPINAS - SP"
},
{ 
   lat: -23.5644560,
   lng: -46.6657810,
   nome: "EMPORIO SANTA LUZIA",
   morada1: "ALAMEDA LORENA - 1471",
   morada2: "CERQUEIRA CESAR",
   codPostal: "CEP: 01424001 - SAO PAULO - SP"
},
{ 
   lat: -22.8970040,
   lng: -47.0664180,
   nome: "CHARLIES PUB",
   morada1: "RUA BARAO GERALDO RESENDE   - 230",
   morada2: "BOTAFOGO",
   codPostal: "CEP: 13020440 - CAMPINAS - SP"
},
{ 
   lat: -26.9158860,
   lng: -49.0850890,
   nome: "PUB BIER VILA",
   morada1: "RUA ALBERTO STEIN - 199",
   morada2: "VELHA",
   codPostal: "CEP: 89036200 - BLUMENAU - SC"
},
{ 
   lat: -22.9016780,
   lng: -47.0561740,
   nome: "GIOVANNETTI CAMBUÍ",
   morada1: "RUA PADRE VIEIRA - 1277",
   morada2: "CAMBUI",
   codPostal: "CEP: 13015301 - CAMPINAS - SP"
},
{ 
   lat: -22.9037870,
   lng: -47.0596590,
   nome: "GIOVANNETTI ROSÁRIO",
   morada1: "RUA GENERAL OSORIO - 1059",
   morada2: "CENTRO",
   codPostal: "CEP: 13010111 - CAMPINAS - SP"
},
{ 
   lat: -22.8691720,
   lng: -47.0419400,
   nome: "CHURRASCARIA GLORIA",
   morada1: "RUA DOM JOAO VI - 148",
   morada2: "VILA NOGUEIRA",
   codPostal: "CEP: 13088005 - CAMPINAS - SP"
},
{ 
   lat: -22.8246890,
   lng: -47.0802400,
   nome: "CONFRARIA DA BARBA BARAO GERALDO",
   morada1: "AV. ALBINO JOSÉ BARBOSA DE OLIVIERA   - 1545",
   morada2: "BARAO GERALDO",
   codPostal: "CEP: 13084008 - CAMPINAS - SP"
},
{ 
   lat: -22.9027350,
   lng: -47.0594680,
   nome: "RESTAURANTE COLISEU ",
   morada1: "R SACRAMENTO - 20",
   morada2: "CENTRO",
   codPostal: "CEP: 13010210 - CAMPINAS - SP"
},
{ 
   lat: -22.8974400,
   lng: -47.0499210,
   nome: "CONFRARIA DA BARBA CAMBUI",
   morada1: "R PADRE ALMEIDA - 238",
   morada2: "CAMBUI",
   codPostal: "CEP: 13025250 - CAMPINAS - SP"
},
{ 
   lat: -22.9515450,
   lng: -47.1105870,
   nome: "CONTAINER BEBIDAS",
   morada1: "RUA ZEQUINHA DE ABREU - 175",
   morada2: "JARDIM CAPIVARI",
   codPostal: "CEP: 13050801 - CAMPINAS - SP"
},
{ 
   lat: -22.9005590,
   lng: -47.0964430,
   nome: "CUIABAR",
   morada1: "AVENIDA BRIGADEIRO RAFAEL TOBIAS DE AGUIAR     - 1179",
   morada2: "JARDIM AURELIA",
   codPostal: "CEP: 13033010 - CAMPINAS - SP"
},
{ 
   lat: -22.8782380,
   lng: -46.9304600,
   nome: "BAR DA CACHOEIRA",
   morada1: "Rua Professora Lídia Abdala - 2,5",
   morada2: "JOAQUIM EGIDIO",
   codPostal: "CEP: 13108046 - CAMPINAS - SP"
},
{ 
   lat: -22.8481910,
   lng: -47.0631890,
   nome: "GIOVANNETTI SHOPPING DOM PEDRO",
   morada1: "AVENIDA GUILHERME CAMPOS - 500",
   morada2: "SANTA GENEBRA",
   codPostal: "CEP: 13087901 - CAMPINAS - SP"
},
{ 
   lat: -22.8840720,
   lng: -47.0528770,
   nome: "DOM KING BARBEARIA",
   morada1: "RUA PAULA BUENO - 850",
   morada2: "TAQUARAL",
   codPostal: "CEP: 13076061 - CAMPINAS - SP"
},
{ 
   lat: -22.8990020,
   lng: -47.0524990,
   nome: "DUNGEON ENGLISH PUB",
   morada1: "R CORONEL QUIRINO - 1730",
   morada2: "CAMBUI",
   codPostal: "CEP: 13025001 - CAMPINAS - SP"
},
{ 
   lat: -10.1823340,
   lng: -48.8806090,
   nome: "EMPORIO PARAISO",
   morada1: "AVENIDA TRANSBRASILIANA - 781",
   morada2: "CENTRO",
   codPostal: "CEP: 77600000 - PARAISO DO TOCANTINS - TO"
},
{ 
   lat: -22.8942380,
   lng: -47.0778380,
   nome: "BAR DO CARIOCA",
   morada1: "RUA ERASMO BRAGA - 1067",
   morada2: "BOMFIM",
   codPostal: "CEP: 13070147 - CAMPINAS - SP"
},
{ 
   lat: -23.3151490,
   lng: -51.1790930,
   nome: "ELIXIR MALTADO",
   morada1: "AVENIDA PRESIDENTE CASTELO BRANCO - 199",
   morada2: "JARDIM PRESIDENTE",
   codPostal: "CEP: 86050460 - LONDRINA - PR"
},
{ 
   lat: -22.8850130,
   lng: -47.0543220,
   nome: "TAP HOUSE",
   morada1: "RUA PAULA BUENO - 664",
   morada2: "TAQUARAL",
   codPostal: "CEP: 13076061 - CAMPINAS - SP"
},
{ 
   lat: -22.9042130,
   lng: -47.0141770,
   nome: "SANTA VERENA",
   morada1: "ALAMEDA DOS VIDOEIROS     - 455",
   morada2: "SITIO RECREIO GRAMADO",
   codPostal: "CEP: 13110680 - CAMPINAS - SP"
},
{ 
   lat: -22.7142750,
   lng: -47.6366590,
   nome: "EMPORIO VEDOVELLO",
   morada1: "R BARAO DE PIRACICAMIRIM           - 1316",
   morada2: "SAO JUDAS",
   codPostal: "CEP: 13416389 - PIRACICABA - SP"
},
{ 
   lat: -20.3412480,
   lng: -40.2865160,
   nome: "EMPORIUM MR. ART",
   morada1: "RUA JOSE PENA MEDINA - 216",
   morada2: "PRAIA DA COSTA",
   codPostal: "CEP: 29101320 - VILA VELHA - ES"
},
{ 
   lat: -22.8987780,
   lng: -47.0698780,
   nome: "BAR DO CLANDESTINO",
   morada1: "AVENIDA BARAO DE ITAPURA     - 479",
   morada2: "BOTAFOGO",
   codPostal: "CEP: 13073300 - CAMPINAS - SP"
},
{ 
   lat: -22.8959250,
   lng: -47.0562870,
   nome: "PIZZA ME CAMBUI",
   morada1: "AVENIDA CORONEL SILVA TELES - 60",
   morada2: "CAMBUI",
   codPostal: "CEP: 13024000 - CAMPINAS - SP"
},
{ 
   lat: -22.8636360,
   lng: -47.2134790,
   nome: "LA PANQUECA HORTOLANDIA",
   morada1: "R JOSE CAMILO DE CAMARGO - 5",
   morada2: "LOTEAMENTO REMANSO CAMPINEIRO",
   codPostal: "CEP: 13184494 - HORTOLANDIA - SP"
},
{ 
   lat: -23.5074110,
   lng: -47.6014730,
   nome: "CANTO BURGER HOUSE",
   morada1: "AVENIDA LUANE MILANDA OLIVEIRA - 341",
   morada2: "JARDIM SANTA CRUZ",
   codPostal: "CEP: 18190000 - ARACOIABA DA SERRA - SP"
},
{ 
   lat: -22.8275790,
   lng: -47.0819140,
   nome: "HIGA BOTECO JAPA BARÃO",
   morada1: "AVENIDA MODESTO FERNANDES - 151",
   morada2: "BARAO GERALDO",
   codPostal: "CEP: 13084190 - CAMPINAS - SP"
},
{ 
   lat: -22.5037820,
   lng: -45.2749410,
   nome: "HOPSHOP",
   morada1: "R PAULINO FARIA  - 745",
   morada2: "FLORESTA",
   codPostal: "CEP: 37514000 - DELFIM MOREIRA - MG"
},
{ 
   lat: -22.9104410,
   lng: -47.0558550,
   nome: "HOTEL IBIS",
   morada1: "AV AQUIDABAN       - 440",
   morada2: "VILA LIDIA",
   codPostal: "CEP: 13026510 - CAMPINAS - SP"
},
{ 
   lat: -22.8974900,
   lng: -47.0494360,
   nome: "STEAK HOUSE RESTAURANTE",
   morada1: "RUA DOUTOR SOUSA LIMA - 3",
   morada2: "CAMBUI",
   codPostal: "CEP: 13025280 - CAMPINAS - SP"
},
{ 
   lat: -2.4920120,
   lng: -44.2599200,
   nome: "VELHO JOHN MUSIC PUB",
   morada1: "AVENIDA DOS HOLANDESES - 9",
   morada2: "CALHAU",
   codPostal: "CEP: 65071380 - SAO LUIS - MA"
},
{ 
   lat: -23.1655350,
   lng: -47.3129060,
   nome: "BAR DU JOAO",
   morada1: "RUA ROMAGNA - 107",
   morada2: "JOAO JABOUR",
   codPostal: "CEP: 13329203 - SALTO - SP"
},
{ 
   lat: -23.5672420,
   lng: -46.6905360,
   nome: "AMBAR CERVEJAS ARTESANAIS",
   morada1: "RUA CUNHA GAGO - 129",
   morada2: "PINHEIROS",
   codPostal: "CEP: 05421000 - SAO PAULO - SP"
},
{ 
   lat: -22.8925140,
   lng: -47.0255360,
   nome: "MONTANA GRILL",
   morada1: "AVENIDA IGUATEMI - 777",
   morada2: "VILA BRANDINA",
   codPostal: "CEP: 13092500 - CAMPINAS - SP"
},
{ 
   lat: -22.7579200,
   lng: -47.1544900,
   nome: "DECK 7",
   morada1: "AVENIDA DOS EXPEDICIONARIOS - 614 a",
   morada2: "JARDIM CALEGARI (NOVA VENEZA)",
   codPostal: "CEP: 13140111 - PAULINIA - SP"
},
{ 
   lat: -22.8100700,
   lng: -47.0787950,
   nome: "GREG BURGERS",
   morada1: "RUA MARIA TEREZA DIAS DA SILVA - 664",
   morada2: "BARAO GERALDO",
   codPostal: "CEP: 13083850 - CAMPINAS - SP"
},
{ 
   lat: -23.0271820,
   lng: -46.9827900,
   nome: "THE GROWLER",
   morada1: "AVENIDA BENEDITO STORANI - 1425",
   morada2: "SANTA ROSA",
   codPostal: "CEP: 13280000 - VINHEDO - SP"
},
{ 
   lat: -22.8238700,
   lng: -47.0833560,
   nome: "LATRO PIZZA",
   morada1: "AVENIDA SANTA ISABEL - 570",
   morada2: "BARAO  GERALDO",
   codPostal: "CEP: 13084012 - CAMPINAS - SP"
},
{ 
   lat: -22.7489610,
   lng: -47.3677490,
   nome: "LA PANQUECA - STA BARBARA",
   morada1: "R DO OSMIO - 699",
   morada2: "JARDIM MOLLON",
   codPostal: "CEP: 13456625 - SANTA BARBARA D OESTE - SP"
},
{ 
   lat: -12.9526960,
   lng: -38.4995130,
   nome: "CLUBE TO BEER",
   morada1: "ESTRADA DA LIBERDADE - 75",
   morada2: "LIBERDADE",
   codPostal: "CEP: 40375017 - SALVADOR - BA"
},
{ 
   lat: -23.0358470,
   lng: -46.9825940,
   nome: "EMPORIO VINHEDO",
   morada1: "AVENIDA DOS IMIGRANTES - 247",
   morada2: "JARDIM ITALIA",
   codPostal: "CEP: 13289130 - VINHEDO - SP"
},
{ 
   lat: -22.8678630,
   lng: -47.0574040,
   nome: "FAZENDAO GRILL",
   morada1: "AV PADRE ALMEIDA GARRET - 1435",
   morada2: "PARQUE TAQUARAL",
   codPostal: "CEP: 13087291 - CAMPINAS - SP"
},
{ 
   lat: -22.8990910,
   lng: -47.0501880,
   nome: "EPICO BURGER - CAMBUI",
   morada1: "RUA DOUTOR EMILIO RIBAS     - 608",
   morada2: "CAMBUI",
   codPostal: "CEP: 13025141 - CAMPINAS - SP"
},
{ 
   lat: -22.9105030,
   lng: -47.0560100,
   nome: "EMPORIO COISA BOA MERCADO CAMPINEIRO",
   morada1: "Rua Barão de Jaguara - 988",
   morada2: "CENTRO",
   codPostal: "CEP: 13015001 - CAMPINAS - SP"
},
{ 
   lat: -23.0381740,
   lng: -46.9848330,
   nome: "MERCATO BURGER",
   morada1: "AVENIDA DOS IMIGRANTES - 636",
   morada2: "JARDIM ITALIA",
   codPostal: "CEP: 13280000 - VINHEDO - SP"
},
{ 
   lat: -22.9172890,
   lng: -47.0497850,
   nome: "BAR CANDREVA ",
   morada1: "AVENIDA MONTE CASTELO - 19",
   morada2: "JARDIM PROENÇA",
   codPostal: "CEP: 13026240 - CAMPINAS - SP"
},
{ 
   lat: -22.9105230,
   lng: -47.0560590,
   nome: "MERCURE CAMPINAS",
   morada1: "AVENIDA AQUIDABAN - 400",
   morada2: "CENTRO",
   codPostal: "CEP: 13026510 - CAMPINAS - SP"
},
{ 
   lat: -22.9895670,
   lng: -47.0037390,
   nome: "PANETTERIA DI MAGRO",
   morada1: "AV INDEPENDENCIA - 2854",
   morada2: "JARDIM SANTO ANTONIO",
   codPostal: "CEP: 13277000 - VALINHOS - SP"
},
{ 
   lat: -22.8961880,
   lng: -47.0542160,
   nome: "MAIALINI",
   morada1: "RUA EMILIA PAIVA MEIRA     - 76",
   morada2: "CAMBUI",
   codPostal: "CEP: 13025040 - CAMPINAS - SP"
},
{ 
   lat: -22.9603300,
   lng: -47.0663190,
   nome: "PIZZERIA ITALY - SWISS PARK",
   morada1: "RUA FRANCISCO ALFREDO JUNIOR - 533",
   morada2: "SWISS PARK",
   codPostal: "CEP: 13049255 - CAMPINAS - SP"
},
{ 
   lat: -22.8104510,
   lng: -47.0789400,
   nome: "PANETTERIA DI CAPRI",
   morada1: "RUA MARIA TEREZA DIAS DA SILVA - 530",
   morada2: "CIDADE UNIVERSITARIA",
   codPostal: "CEP: 13084190 - CAMPINAS - SP"
},
{ 
   lat: -22.9222510,
   lng: -47.0837220,
   nome: "PEIXINHOS RESTAURANTE",
   morada1: "AVENIDA FRANCISCO DE PAULA OLIVEIRA NAZARETH - 389",
   morada2: "PARQUE INDUSTRIAL",
   codPostal: "CEP: 13031440 - CAMPINAS - SP"
},
{ 
   lat: -22.9756820,
   lng: -46.9965470,
   nome: "BAR E PIZZARIA FRATELLO",
   morada1: "AV INDEPENDENCIA - 601",
   morada2: "JARDIM SANTO ANTONIO",
   codPostal: "CEP: 13277000 - VALINHOS - SP"
},
{ 
   lat: -22.9064800,
   lng: -47.0540580,
   nome: "RESTAURANTE PONTO UM",
   morada1: "R BOAVENTURA DO AMARAL - 788",
   morada2: "CENTRO",
   codPostal: "CEP: 13015191 - CAMPINAS - SP"
},
{ 
   lat: -22.8955700,
   lng: -47.0507380,
   nome: "NASHI CAMBUI",
   morada1: "RUA PADRE ALMEIDA - 639",
   morada2: "CAMBUI",
   codPostal: "CEP: 13025250 - CAMPINAS - SP"
},
{ 
   lat: -22.8803780,
   lng: -47.0548610,
   nome: "DJANGO BREW HOUSE",
   morada1: "AVENIDA BARÃO DE ITAPURA  - 3033",
   morada2: "JARDIM GUANABARA",
   codPostal: "CEP: 13073300 - CAMPINAS - SP"
},
{ 
   lat: -22.9096880,
   lng: -47.0469570,
   nome: "BAR  DA ZEPHA",
   morada1: "R URUGUAIANA - 1266",
   morada2: "BOSQUE",
   codPostal: "CEP: 13026002 - CAMPINAS - SP"
},
{ 
   lat: -22.8865930,
   lng: -47.0618170,
   nome: "ROSTISSERIE BBQ",
   morada1: "RUA BUARQUE DE MACEDO - 150",
   morada2: "JD. BRASIL",
   codPostal: "CEP: 13073010 - CAMPINAS - SP"
},
{ 
   lat: -22.8796880,
   lng: -47.0543890,
   nome: "CERVEJOTECA CAMPINAS",
   morada1: "R AVENIDA BARAO DE ITAPURA - 3133",
   morada2: "JARDIM GUANABARA",
   codPostal: "CEP: 13073300 - CAMPINAS - SP"
},
{ 
   lat: -22.9199810,
   lng: -47.0769510,
   nome: "MILORD TAVERNA",
   morada1: "AV MINAS GERAIS - 194",
   morada2: "FUNDACAO DA CASA POPULAR",
   codPostal: "CEP: 13031260 - CAMPINAS - SP"
},
{ 
   lat: -22.8891440,
   lng: -47.0522550,
   nome: "SALUMI ",
   morada1: "RUA DOUTOR SAMPAIO PEIXOTO - 284",
   morada2: "CAMBUI",
   codPostal: "CEP: 13024420 - CAMPINAS - SP"
},
{ 
   lat: -22.8945620,
   lng: -47.0600530,
   nome: "BRONCO BURGER CAMBUI",
   morada1: "RUA JOSE VILLAGELIM JUNIOR - 25",
   morada2: "CAMBUI",
   codPostal: "CEP: 13082690 - CAMPINAS - SP"
},
{ 
   lat: -22.8657700,
   lng: -47.0241080,
   nome: "AUROK",
   morada1: "AV DOUTOR JOSE BON COT NOGUEIRA  - 214",
   morada2: "JARDIM MADALENA",
   codPostal: "CEP: 13091611 - CAMPINAS - SP"
},
{ 
   lat: -22.9719070,
   lng: -47.0653900,
   nome: "SWISS BEER BEEF",
   morada1: "AV DERMIVAL BERNARDE SIQUEIRA - 1934",
   morada2: "SWISS PARK",
   codPostal: "CEP: 13049252 - CAMPINAS - SP"
},
{ 
   lat: -22.9042130,
   lng: -47.0141770,
   nome: "TAXI BEER",
   morada1: "RUA DOS VIDOEIROS - 455",
   morada2: "SITIOS DE RECREIO GRAMADO",
   codPostal: "CEP: 13101680 - CAMPINAS - SP"
},
{ 
   lat: -22.8824260,
   lng: -46.9717620,
   nome: "BARBEARIA BOX 9",
   morada1: "AVENIDA ANTONIO CARLOS COUTO DE BARROS  - 650",
   morada2: "VILA SONIA (SOUZAS)",
   codPostal: "CEP: 13105500 - CAMPINAS - SP"
},
{ 
   lat: -22.8264870,
   lng: -47.0833200,
   nome: "ARMAZEM NOBRE",
   morada1: "R ANGELO VICENTIM - 226",
   morada2: "BARAO GERALDO",
   codPostal: "CEP: 13084060 - CAMPINAS - SP"
},
{ 
   lat: -22.9805080,
   lng: -47.0209610,
   nome: "ULIER CERVEJARIA",
   morada1: "RUA PAIQUERE - 1540",
   morada2: "JARDIM PAIQUERE",
   codPostal: "CEP: 13271600 - VALINHOS - SP"
},
{ 
   lat: -23.6042170,
   lng: -46.6436120,
   nome: "Cervejatorium",
   morada1: "Rua das Rosas - 797 ",
   morada2: "Mirandopolis",
   codPostal: "CEP: 04048001  - São Paulo - SP"
},
{ 
   lat: -23.5290290,
   lng: -46.5451790,
   nome: "Armazem 77 ",
   morada1: "Rua Betari - 525 ",
   morada2: "Penha",
   codPostal: "CEP: 3634040 - São Paulo - SP"
},
{ 
   lat: -23.5267830,
   lng: -46.8217540,
   nome: "Hermano PUB",
   morada1: "Rua Egeu - 213 ",
   morada2: " ",
   codPostal: "CEP:  - Carapicuiba - SP"
},
{ 
   lat: -23.5976330,
   lng: -46.6501110,
   nome: "Quitanda Beer ",
   morada1: "Rua Pedro de Toledo - 1378 ",
   morada2: "Vila Clementino",
   codPostal: "CEP: 4039003 - São Paulo - SP"
},
{ 
   lat: -23.5332970,
   lng: -46.6569200,
   nome: "Porao da Cerveja",
   morada1: "Av. Gal Olimpio da Silveira - 9 – ss ",
   morada2: "Santa Cecilia ",
   codPostal: "CEP: 1150020 - São Paulo - SP"
},
{ 
   lat: -23.5305910,
   lng: -46.6573210,
   nome: "CASA 599",
   morada1: "Rua Brigadeiro Galvão - 599 ",
   morada2: "Barra Funda",
   codPostal: "CEP: 1151000 - São Paulo - SP"
},
{ 
   lat: -23.5438120,
   lng: -46.6544260,
   nome: "Lira Bar Empório",
   morada1: "Rua Marques de Itu - 1039 ",
   morada2: "Higienopolis",
   codPostal: "CEP: 1223001 - São Paulo - SP"
},
{ 
   lat: -23.6307900,
   lng: -46.6418730,
   nome: "Sampa On Tap ",
   morada1: "Av. Pedro Severino Jr. - 390 ",
   morada2: "Jabaquara",
   codPostal: "CEP: 4310060 - São Paulo - SP"
},
{ 
   lat: -23.5026850,
   lng: -46.6319590,
   nome: "Bavaros Bier",
   morada1: "Rua Dr. Cesar - 588 ",
   morada2: "Santana",
   codPostal: "CEP: 2013002 - São Paulo - SP"
},
{ 
   lat: -23.5514600,
   lng: -46.6796740,
   nome: "Canto do Saci",
   morada1: "Rua Amalia de Noronha - 181 ",
   morada2: "Pinheiros",
   codPostal: "CEP: 5410010 - São Paulo - SP"
},
{ 
   lat: -23.5565640,
   lng: -46.6882380,
   nome: "EMPORIO SAGARANA",
   morada1: "Rua Aspicuelta - 268 ",
   morada2: "Alto dos Pinheiros",
   codPostal: "CEP: 5433010 - São Paulo - SP"
},
{ 
   lat: -23.5737650,
   lng: -46.6230900,
   nome: "Circless Shopp",
   morada1: "Av. Lins de Vasconcelos - 1170 ",
   morada2: "Cambuci",
   codPostal: "CEP: 1538001 - São Paulo - SP"
},
{ 
   lat: -23.4594160,
   lng: -46.5050010,
   nome: "Veio Venal",
   morada1: "Av. Nossa Sra. de Fátima - 697 ",
   morada2: " ",
   codPostal: "CEP: 7191190 - Guarulhos - SP"
},
{ 
   lat: -23.5113320,
   lng: -46.6275960,
   nome: "Brew World Beer",
   morada1: "Rua Santa Eulalia - 75 ",
   morada2: "Santana",
   codPostal: "CEP: 2031020 - São Paulo - SP"
},
{ 
   lat: -23.6264700,
   lng: -46.6662190,
   nome: "Iguana Beer ",
   morada1: "Rua Sebastião Paes - 401 ",
   morada2: "Campo Belo",
   codPostal: "CEP: 4625061 - São Paulo - SP"
},
{ 
   lat: -23.5816720,
   lng: -46.6059760,
   nome: "Cheers Burger",
   morada1: "Rua Benjamim Jaffet - 281 ",
   morada2: "Ipiranga",
   codPostal: "CEP: 4203040 - São Paulo - SP"
},
{ 
   lat: -23.5311770,
   lng: -46.6629290,
   nome: "Armazem Garnizé",
   morada1: "Largo Padre Péricles - 110  ",
   morada2: "Barra Funda",
   codPostal: "CEP: 1156040 - São Paulo - SP"
},
{ 
   lat: -21.7927640,
   lng: -46.5615300,
   nome: "Mestre-Cervejeiro.com Poços de Caldas",
   morada1: "Av Santo Antônio - 379",
   morada2: "Jd Cascatinha",
   codPostal: "CEP: 37701830 - Poços de Caldas - MG"
},
{ 
   lat: -21.7868460,
   lng: -46.5660080,
   nome: "Café Concerto",
   morada1: "",
   morada2: "Centro",
   codPostal: "CEP: 37701000 - Poços de Caldas - MG"
},
{ 
   lat: -21.9234080,
   lng: -46.3885420,
   nome: "Big Lanches Hamburgueria Goumet",
   morada1: "",
   morada2: "Centro",
   codPostal: "CEP: 37780000 - Caldas - MG"
}
];


function initialize() {
   var mapOptions = {
      center: new google.maps.LatLng(-22.830103,-47.0776515),
      zoom: 13,
      mapTypeId: 'roadmap',
   };

   map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);

   // cria a nova Info Window com referência à variável infowindow
   // o conteúdo da Info Window será atribuído mais tarde
   infoWindow = new google.maps.InfoWindow();

   // evento que fecha a infoWindow com click no mapa
   google.maps.event.addListener(map, 'click', function() {
      infoWindow.close();
   });

   // Chamada para a função que vai percorrer a informação
   // contida na variável markersData e criar os marcadores a mostrar no mapa
   displayMarkers();
}
google.maps.event.addDomListener(window, 'load', initialize);

// Esta função vai percorrer a informação contida na variável markersData
// e cria os marcadores através da função createMarker
function displayMarkers(){

   // esta variável vai definir a área de mapa a abranger e o nível do zoom
   // de acordo com as posições dos marcadores
   var bounds = new google.maps.LatLngBounds();
   
   // Loop que vai estruturar a informação contida em markersData
   // para que a função createMarker possa criar os marcadores 
   for (var i = 0; i < markersData.length; i++){

      var latlng = new google.maps.LatLng(markersData[i].lat, markersData[i].lng);
      var nome = markersData[i].nome;
      var morada1 = markersData[i].morada1;
      var morada2 = markersData[i].morada2;
      var codPostal = markersData[i].codPostal;
      var lat1 = markersData[i].lat;
      var lng1 = markersData[i].lng;

      createMarker(latlng, nome, morada1, morada2, codPostal, lat1, lng1);

      // Os valores de latitude e longitude do marcador são adicionados à
      // variável bounds
      bounds.extend(latlng);  
   }

   // Depois de criados todos os marcadores
   // a API através da sua função fitBounds vai redefinir o nível do zoom
   // e consequentemente a área do mapa abrangida.
   map.fitBounds(bounds);
}

// Função que cria os marcadores e define o conteúdo de cada Info Window.
function createMarker(latlng, nome, morada1, morada2, codPostal, lat1, lng1){
   var marker = new google.maps.Marker({
      map: map,
      position: latlng,
      title: nome,
      icon: '../images/icons/ico-beer.png',
   });

   // Evento que dá instrução à API para estar alerta ao click no marcador.
   // Define o conteúdo e abre a Info Window.
   google.maps.event.addListener(marker, 'click', function() {
      
      // Variável que define a estrutura do HTML a inserir na Info Window.
      var iwContent = '<div id="iw_container">' +
            '<div class="iw_title"><b>' + nome + '</b></div>' + 
         '<div class="iw_content">' + morada1 + '<br>' +
         morada2 + '<br>' +
         codPostal + '<br><br> <a href="https://waze.com/ul?ll=' + lat1 + ',' + lng1 + '&navigate=yes" target="_blank"><b>Veja como chegar</b></a></div></div>';
      
      // O conteúdo da variável iwContent é inserido na Info Window.
      infoWindow.setContent(iwContent);

      // A Info Window é aberta.
      infoWindow.open(map, marker);
   });
}